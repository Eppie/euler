#include <cstdlib>
#include <cstdio>

bool is_SPRP( uint64_t n, uint64_t a, uint64_t d, uint64_t s ) {
  uint64_t cur = 1;
  for(; d > 0; d >>= 1) {
  //while( d ) {
    if( d & 1 ) {
      cur = ( cur * a ) % n;
    }
    a = ( a * a ) % n;
    //d >>= 1;
  }
  if( cur == 1 ) {
    return true;
  }
  for( uint32_t r = 0; r < s; r++ ) {
    if( cur == n - 1 ) {
      return true;
    }
    cur = ( cur * cur ) % n;
  }
  return false;
}

int main() {
  uint64_t n = 16607;
  uint64_t d = n - 1;
  uint64_t s = __builtin_ctz( d );
  d >>= s;
  uint64_t sum = 0;
  for( uint64_t a = 2; a <= 65536; ++a ) {
  sum += is_SPRP(n, a, d, s);
  }
  printf("%llu\n", sum);
	return 0;
}
